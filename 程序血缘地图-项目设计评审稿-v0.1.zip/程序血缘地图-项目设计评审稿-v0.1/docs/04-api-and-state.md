# 接口与前端状态契约

这是替代旧交接件歧义的**接口设计草案**，不是已实现或已校验的 OpenAPI。正式开发前需按选定平台形成唯一 schema、校验示例并生成客户端类型。

## 1. 一次探索的固定上下文

`POST /api/lineage/queries` 建立上下文：输入 `seedId`、可选 snapshotId，服务端返回 `queryId, seed, snapshotId, policyVersion, algorithmVersion, coverage, computationStatus, stats, initialProjection`。查询授权与当前登录绑定，不信任客户端提供授权指纹。

同一个 queryId 的关系分类和 layoutRank 不因页面翻页、类型筛选或局部展开改变。queryId 不是历史凭据，可过期；可复现链接使用根和快照参数重新鉴权构建查询。

结构计算必须在完整授权可达图上完成。达到计算预算时：返回 incomplete 状态与下界/未知计数，不返回伪装稳定的完整树分类。若本轮图未完整，不把它与先前完整图增量合并；引导缩小数据范围或重试。

## 2. 接口清单

| 接口 | 输入核心 | 输出及规则 |
|---|---|---|
| GET `/api/lineage/search` | q、queryId?、type?、cursor、limit | 授权匹配对象；有 queryId 时表可用于换根，非表需在当前下游 |
| POST `/api/lineage/queries` | seedId、snapshotId? | 创建上下文并返回默认主树一层投影 |
| POST `/api/lineage/queries/{qid}/projection` | mode、layoutDepth、types、expandedIds、revealedIds、cursor?、nodeBudget | 返回当前完整的有界画布投影；无业务事实写入 |
| POST `/api/lineage/queries/{qid}/children` | parentId、cursor、limit、types、activeNodeIds、clientRevision | 一层主树子节点页、对象元数据、rank、父边及连线闭包；只接受当前上下文中合法 ID |
| GET `/api/lineage/queries/{qid}/overview` | types、cursor、limit | 按 layoutRank×type 的簇数量；不下发所有成员 |
| GET `/api/lineage/queries/{qid}/clusters/{cid}/members` | cursor、limit | 簇成员页；成员排序稳定 |
| GET `/api/lineage/queries/{qid}/impact` | types、system、cursor、limit | 独立的完整可达下游分页，默认根不计入；不受画布层级限制 |
| GET `/api/lineage/queries/{qid}/nodes/{id}` | id | 元数据、minHops、layoutRank、主父、直接关系数、跨支数、操作能力 |
| GET `/api/lineage/queries/{qid}/nodes/{id}/relations` | relationClass、cursor、limit | 主/跨支邻接及另一端元数据，帮助发现尚未绘制对象 |
| GET `/api/lineage/queries/{qid}/path` | targetId | 一条最短下游路径；完整上下文中无路返回 found=false |
| GET `/api/lineage/queries/{qid}/relations/{rid}/evidence` | rid | 当前可授权的关系来源、位置、时间、状态 |

如果系统已有 API 规范可调整路径和 GET/POST，但必须保留版本、授权、分页和完整性语义。qid/cid/rid 均为不透明 URL 安全标识，显示名不能直接代替。

## 3. 响应元数据

所有查询响应携带 `queryId, snapshotId, requestId`，视图响应还带 `clientRevision` 回显。主要状态拆为：

| 字段 | 值/含义 |
|---|---|
| coverage | complete / partial / unknown，描述来源在声明范围内的覆盖 |
| computationStatus | complete / incomplete，描述本次查询计算是否完成 |
| treeStatus | available / unavailable_cycle / unavailable_incomplete |
| countStatus | exact / lower_bound / unknown，描述随附统计 |
| hasMore | 当前成员/子节点页是否还有数据 |
| nextCursor | 不透明游标，绑定上下文、筛选和排序 |
| renderLimited | 当前画布因渲染预算裁剪；不等于数据未知 |
| reasons | 例如 SOURCE_PARTIAL、QUERY_BUDGET、PAGE_LIMIT；不携带未授权信息 |

错误 shape 固定为 `{code,message,requestId,retryable}`，不把原始 SQL、异常栈或敏感名称放到 message。

## 4. 子节点与跨支增量契约

原 children 接口缺少“当前画布有哪些对象”的信息，这里采用有界 `activeNodeIds` + `clientRevision`，仅用于连线闭包，不用于决定授权或主父。

服务端返回：本页 children（去重 ID）、节点详情、每个新节点的 `layoutRank,minHops,parentEdgeId`，以及 `activeNodeIds ∪ newNodeIds` 集合内、至少一端在 newNodeIds 中的所有可展示主边/跨支。这些边分为独立 `relationId`；已有相同 ID 时前端幂等合并。

若相关边数也超过预算，先减少本页节点数量，保证该子图边闭包完整；如果单节点关系量仍超预算，返回需转投影/聚合的明确结果，不静默漏线。未在画布集合中的跨支不下发孤立线段，但必须由节点跨支总数和 relations 分页入口发现。

用户从跨支列表定位一个未显示对象时，projection 输入 revealedIds，服务端补齐必要主树祖先，并在预算允许时返回该对象与当前选中对象的跨支；超过预算时切总览/关系列表说明，不偷偷改变它的主父。

例：先展开 A 获得 X，再展开 B 获得 Y，且 X→Y 为跨支。第二次返回 Y 时必须带 X→Y；反过来先展开 B 再 A 也必须能得到同一条边。分页先后不改变最终分类与计数。

## 5. 分页及统计

建议子节点/清单每页 50，最大 100；节点画布初始预算 100、硬上限 200，具体须按目标设备校准。对象排序以类型序+规范名称+objectId 固定；游标带筛选摘要，筛选变化必须废弃旧游标。同页重试去重，不让总数递增。

根对象在一般查询 seed 字段返回，影响清单排除根。stats 用全范围口径；筛选匹配数另报，不用 loaded 或 rendered 数回填。`hiddenTreeChildren = 匹配的唯一主子节点总数 - 当前实际显示的匹配子节点数`，不能把 childCount 直接作为未显示数。

## 6. 前端状态分层

| 层 | 字段 | 生命周期 |
|---|---|---|
| URL | seedId、snapshotId?、mode、selectedId、layoutDepth、types、pathTargetId | 刷新/链接复现；任何值须服务端重验 |
| 查询上下文 | queryId、snapshotId、版本、stats、完整性 | 换根/刷新/授权变化时重建 |
| 对象缓存 | 按 queryId 的 nodes、relations、page cursors | 禁止跨上下文直接合并 |
| 展示会话 | expandedIds、revealedIds、折叠簇、viewport、选中态 | 切视图尽量保留；换根清空 |
| 请求状态 | requestRevision、分区域 loading/error、abort handle | 避免旧请求覆盖新结果 |

URL 复现保证根、快照、视图、筛选、选中和目标；不保证像素位置与所有手工展开。若 selectedId 有效但初始不可见，恢复时调用定位投影，不生成指向隐藏对象的空详情。未指定 snapshotId 的链接代表最新数据，页面明确注明。

## 7. 状态转换

| 事件 | 必要行为 |
|---|---|
| 初次加载 | idle→loading→ready / empty / error；只在权限与数据检查通过后展示图 |
| 选中 | 更新 selection，详情独立加载；旧详情响应不得覆盖新选中 |
| 展开 | 按 parent loading；同 parent 不重复请求；完成时核对 qid/revision |
| 收起 | 撤销该分支展开，但保留仍因其他有效展开/定位需要的节点；清理悬空线 |
| 类型筛选 | 更新呈现与匹配计数；树分类不变；隐藏路径提供恢复入口 |
| 全部层级 | 强制 overview，使用聚类接口；不要用 99 魔法值表示无限 |
| 换根 | 取消旧请求，重置选择/展开/目标/游标；创建新上下文 |
| 新数据刷新 | 固定新快照重新计算，旧结果标旧版本且不可混合 |
| 无权限/权限失效 | 清除该查询缓存；不保留旧详情闪现 |
| 搜索定位 | 当前下游定位；域外表换根；请求失败保留原有效地图 |

同页 A 请求晚于 B 返回时，按 revision 丢弃 A 的 UI 写入。丢弃是会话状态控制，不能只靠请求取消，因为响应可能已经在途中。

## 8. 错误语义

建议：400 INVALID_ARGUMENT / INVALID_SEED；401 UNAUTHENTICATED；403 FORBIDDEN；404 NOT_FOUND；409 LINEAGE_NOT_COLLECTED / SNAPSHOT_CHANGED；410 QUERY_EXPIRED；429 RATE_LIMITED；503 TEMPORARILY_UNAVAILABLE。

根 403 与 404 是否统一对外返回取决于现有平台的对象存在性策略，默认不泄露不存在与不可访问的差别。根已授权后，可明确区分未采集与已采集无下游。

环与查询不完整优先作为结构化结果状态，提供清单/路径可用能力；不要统一为“绘制失败”。路径只有完整查询已证明不可达才可 found=false；未完成则返回 PATH_UNKNOWN 结果状态。
